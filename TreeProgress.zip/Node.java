//Node Class
 public class Node{

  private String data;
  private Node left;
  private Node right;
  
  public Node(String data){
    this.data = data;
  }
  
  public void setLeft(Node myLeft){
    this.left = myLeft; 
  }
  
   public void setRight(Node myRight){
     this.right = myRight; 
  }
   
   public Node getLeft(){
     return this.left;
  }
  
   public Node getRight(Node right){
     return this.right;
  }
   
   public void printNode(){
    System.out.println(this.data); 
   }


}
