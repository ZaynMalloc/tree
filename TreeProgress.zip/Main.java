public class Main{
  
  public static void main(String[] args){
    
   Node newNode = new Node("Hello World");
   newNode.printNode();
  }
  
}